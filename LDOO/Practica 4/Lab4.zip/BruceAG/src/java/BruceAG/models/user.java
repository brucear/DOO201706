/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BruceAG.models;

/**
 *
 * @author FCFM-3
 */
public class user{
    private String username;
    private String password;
    
    public user(String x, String y){
        this.password = y;
        this.username = x;
    }
    
    public String getUsername(){
        return username;
    }
    
    
}
