/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio9.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Bruce Araujo Guerrero 1837606
 */
public class Log {
    private String fileName;
    private static Log instance = null;
    
    private Log(){
       
    }

 
    public static Log getInstance(){
        if(instance == null){
            instance = new Log();
         }
            return instance;
        
    }

 
    public void write(String message){
                message = null;
            try (BufferedWriter br = new BufferedWriter(new FileWriter(fileName, true))) { 
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Calendar cal = Calendar.getInstance();

                        //Create the name of the file from the path and current time
                        String data = "\n" + dateFormat.format(cal.getTime()) + ": " + message ;
                        br.write(data);
            }

catch(Exception e) { }
    }
}
