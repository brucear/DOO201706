/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bruce Araujo Guerrero 1837606
 */
public class ComentariosDAO {
    Connection conexion;
    
    public void abrirConexion() throws SQLException{
        String dbURI = "jdbc:derby://localhost:1527/Comentarios";
        String username = "fcfm";
        String password = "lsti01";
        conexion = DriverManager.getConnection(dbURI, username, password);
        
    }
    private void cerrarConexion() throws SQLException{
        conexion.close();
    }
    public void insert(ComentariosPOJO x){
        
        try{
            
        abrirConexion();
        String SQL = "('x.getNombre()', 'x.getComentario()')";
        Statement stmt = conexion.createStatement();
        stmt.executeUpdate(SQL);
        conexion.close();
        }catch(SQLException y){
            
        }
        
    }
    public List buscar(){
        List lista = null;
        ResultSet result = null;
        List algo = new ArrayList();
        
        
        try{
            abrirConexion();
        }catch(SQLException y){}         
        return (null);
            }
}