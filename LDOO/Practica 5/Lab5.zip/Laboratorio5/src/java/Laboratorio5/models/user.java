/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio5.models;

/**
 *
 * @author FCFM-3
 */
public class user{
    private String username;
    private String password;
    private String Nombre;
    private String Apellidos;
    
    
    public user(String x, String y){
        this.password = y;
        this.username = x;
        this.Nombre = "Bruce";
        this.Apellidos = "Araujo";
    }
    
    public String getUsername(){
        return username;
    }
    
    public String getName(){
        return Nombre;
    }
    
    public String getLastName(){
        return Apellidos;
    }
    
    public String getFullName(){
        return getName() + getLastName();
    }
    
    
}
